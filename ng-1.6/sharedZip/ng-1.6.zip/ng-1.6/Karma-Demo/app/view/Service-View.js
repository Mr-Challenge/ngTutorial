app.controller('ServiceCtrl',function($scope,AddService){
	$scope.addResult = AddService.add(5,6);
});
		