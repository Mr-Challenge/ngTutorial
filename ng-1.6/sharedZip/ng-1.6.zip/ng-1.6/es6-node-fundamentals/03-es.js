/*JavaScript Primitives -  Values cannot be changed*/
var numberVar  = 5;
var stringVar  = 'Karthik';
var booleanVar = false;
var undefinedVar;
var nullVar = null;
console.log(stringVar);
console.log(typeof(undefinedVar));
console.log(undefinedVar === undefined);

