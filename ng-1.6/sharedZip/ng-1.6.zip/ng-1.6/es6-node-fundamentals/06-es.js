var addNumbers = function(a,b){
    return a + b;
}
console.log(typeof(addNumbers)) // function
console.log(addNumbers(5,6));