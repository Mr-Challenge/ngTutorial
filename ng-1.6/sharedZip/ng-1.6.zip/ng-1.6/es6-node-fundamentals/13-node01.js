var Calculator = require('./calculator'); //importing the module with the relative reference
console.log(Calculator.add(5,6));
console.log(Calculator.multiply(5,6));
