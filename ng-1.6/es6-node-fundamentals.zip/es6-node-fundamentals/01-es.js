console.log('Welcome to Node.js');

/*
To Run the program 
> node es01.js
 */