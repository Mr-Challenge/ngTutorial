for(;;){
    console.log('Hello');
}

/*To Stop the execution CTRL + C */
